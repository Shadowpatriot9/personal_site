# Welcome

## Introduction
Here I routinely edit and host my personal site following a MERN stack (previously on a LAMP stack) and deploy it through the PaaS "Vercel". 
I do my best to make sure the info is up to date but understand that an out of date version may be posted so please verify the dates of the latest commits to verify the information.

## Link
The link is under the 'About' section on the right panel of the repo, <br>
but in case you want it here too; here you go :) <br>
Link: https://mgds.me/

<br>

That's it from me though, let me know how my personal secrets look to ya ;)

<br>

> [!Note]
> I'm keeping the monkey on the readme btw....
> <br>
> I like him and his name is Paul :D

![giphy](https://github.com/user-attachments/assets/abbb34ac-f83a-49be-a46c-1d019fd19526)
